#ifndef __DETECTOR_PERSONAJES_H__
#define __DETECTOR_PERSONAJES_H__

/*
 * Asignará un caracter según sea detectado un personaje por medio de ciertas preguntas de caracteristicas.
*/
void detectar_personaje(char* personaje_detectado);

#endif /* __DETECTOR_PERSONAJES_H__ */